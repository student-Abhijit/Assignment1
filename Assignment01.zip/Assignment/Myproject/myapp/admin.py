from django.contrib import admin

# Register your models here.

# from.models import hospital 
from.models import hospitaldash 
admin.site.register(hospitaldash)


# admin.site.register(hospital)
